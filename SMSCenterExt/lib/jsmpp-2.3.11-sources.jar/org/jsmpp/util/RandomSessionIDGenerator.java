/*
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at
 * 
 *    http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.jsmpp.util;

import java.util.Random;

/**
 * Session id generator.
 * 
 * @author uudashr
 * @version 1.0
 * @since 1.0
 *
 */
public class RandomSessionIDGenerator implements SessionIDGenerator<String> {
	private final Random random = new Random();
	
	/**
	 * Generate new session id. Max 64 char.
	 */
	public String newSessionId() {
		byte[] b = new byte[32];
		random.nextBytes(b);
		return HexUtil.convertBytesToHexString(b);
	}
}
